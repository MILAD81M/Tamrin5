import random

class car:
    def __init__(self, color, acceleration, brake_acc, max_speed, fuel_cap, fuel_con, Previous_position=0, initial_fuel=0, A=0, B=0):
        self.color = color
        self.acceleration = acceleration
        self.fuel_cap = fuel_cap
        self.fuel_con = fuel_con
        self.brake_acc = brake_acc
        self.max_speed_initial = max_speed
        self.max_speed = max_speed
        self.speed = 0
        self.position = 0
        self.fuel_level = self.fuel_cap
        self.Previous_position = Previous_position
        self.initial_fuel = initial_fuel
        self.A = A
        self.B = B
        self.refueling_stations = [300, 600, 900]  

    def accelerate(self):
        self.max_speed = self.max_speed_initial - 30 + (30 * ((self.fuel_cap - self.fuel_level) / self.fuel_cap))
        if (self.acceleration + self.speed) < self.max_speed and self.A == 0:
            self.speed += self.acceleration

    def brake(self):
        if self.speed >= self.brake_acc:
            self.speed -= self.brake_acc
        else:
            self.speed = 0

    def drive(self, sec):
        for station in self.refueling_stations:
            if self.position < station and self.position + (self.speed / 3600) >= station:
                self.refuel_decision(station, sec)
        if self.fuel_level > 0:
            if self.A > 0:
                self.A -= 1
                print(name_cars[i], f"speed={self.speed} KM/h", f"position={self.position:.2f} KM", f"fuel level={self.fuel_level:.2f} liters", 'Refueling =', self.B)
            else:
                self.Previous_position = self.position
                self.position += (self.speed / 3600)
                self.fuel_level1()
                print(sec, name_cars[i], f"speed={self.speed} KM/h", f"position={self.position:.2f} KM", f"fuel level={self.fuel_level:.2f} liters", 'Refueling =', self.B)
        else:
            print(name_cars[i], "speed=0", f"position={self.position:.2f} KM", "fuel level=ran out of fuel")

    def refuel_decision(self, station, sec):
        distance_to_destination = 1000 - self.position
        fuel_needed_to_destination = (distance_to_destination / 100) * self.fuel_con

        if self.fuel_level < fuel_needed_to_destination:
            required_fuel = fuel_needed_to_destination - self.fuel_level
            if(required_fuel>=self.fuel_cap):required_fuel=self.fuel_cap-self.fuel_level
            self.refuel(required_fuel)
            while self.speed > 0:
                self.brake()
            print(f"Approaching refueling station at {station} KM. Refueling {required_fuel:.2f} liters. Total seconds: {sec}")

    def refuel(self, amount):
        if self.A == 0:
            self.fuel_level += amount
            self.A = int(amount)  
            self.B += amount
            print(f"Refueled {amount:.2f} liters. Current fuel level: {self.fuel_level:.2f} liters")

    def fuel_level1(self):
        if (self.fuel_level - (self.fuel_con * ((self.position - self.Previous_position) / 100))) >= 0:
            self.fuel_level -= (self.fuel_con * ((self.position - self.Previous_position) / 100))
        else:
            self.fuel_level = 0
            self.speed = 0

carA = car("Blue", 3, 6, 123, 36, 10, 4, 0)
carB = car("Red", 4, 6, 130, 40, 9, 4, 0)
carC = car("Green", 2, 6, 150, 50, 8, 4, 0)
carD = car("Purple", 5, 6, 140, 60, 7, 4, 0)
cars = [carA, carB, carC, carD]
name_cars = ["carA", "carB", "carC", "carD"]

def Specifications_car():
    i = 0
    for Selected_car in cars:
        selected_color = random.choice(["red", "blue", 'green', "purple"])
        Selected_acceleration = random.randrange(2, 8)
        selected_brake_acc = random.randrange(20, 80)
        selected_max_speed = random.randrange(110, 221)
        selected_fuel_cap = random.choice([30, 40, 50, 60, 70, 80])
        selected_initial_fuel = random.randrange(30, selected_fuel_cap + 1)
        selected_fuel_con = random.randrange(6, 16)
        Selected_car.color = selected_color
        Selected_car.acceleration = Selected_acceleration
        Selected_car.brake_acc = selected_brake_acc
        Selected_car.max_speed_initial = selected_max_speed
        Selected_car.max_speed = selected_max_speed
        Selected_car.fuel_cap = selected_fuel_cap
        Selected_car.fuel_con = selected_fuel_con
        Selected_car.fuel_level = selected_initial_fuel
        Selected_car.initial_fuel = selected_initial_fuel
        print(name_cars[i], "color=", Selected_car.color, "acceleration =", Selected_car.acceleration, "brake acceleration=", Selected_car.brake_acc, "max speed=", Selected_car.max_speed, "fuel capacity=", Selected_car.fuel_cap, "Fuel consumption=", Selected_car.fuel_con, "initial fuel=", Selected_car.initial_fuel)
        i += 1

Specifications_car()
total_seconds = 0
key = input("start by pressing 's': ")
while key == 's':
    for sec in range(total_seconds + 1, total_seconds + 3601):
        for i in range(0, 4):
            cars[i].accelerate()
            cars[i].drive(sec)
            if cars[i].position >= 1000:
                print(f"{name_cars[i]} has reached the destination in {sec/3600:.2f} hours!")
                key = 'q'
                break
        if key == 'q':
            break

    total_seconds += 3600
    if key != 'q':
        key = input("Press 's' to start another round: ")
